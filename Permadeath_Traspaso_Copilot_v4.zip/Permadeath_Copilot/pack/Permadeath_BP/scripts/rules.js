// Pure rules derived from the supplied JAR. Differences are listed in GUIA.md.
export const END_SLOTS = [4,13,22,31];
export const BEGIN_SLOTS = [7,8,9,10,11,12,14,15,16,17,18,19,20,21,23,24,25,26,27,28,29,30,32,33,34];
export function clampDay(n) { return Math.max(0,Math.min(70,Math.floor(Number(n)||0))); }
export function dayAt(s,now) {
 if(s.paused) return clampDay(s.baseDay);
 const elapsed = s.clock==='real' ? Math.max(0,now-s.epoch)/1000 : s.elapsed;
 return clampDay(s.baseDay+Math.floor(elapsed/s.daySeconds));
}
export function stormSeconds(day) { const rem=day%25; return (rem===0?1:day<=25?rem:rem+1)*(day>=50?1800:3600); }
export function totemRule(day) {return {failure:day>=70?0:day<40?.01:day<50?.03:.05,count:day>=70?1:day<40?1:day<60?2:3};}
export function healthLimit(day,apples,armor,orb,orbActive) {
 if(day>=70) return 20+apples*4+armor;
 return Math.max(2,20+apples*4+armor-(day>=40?8:0)-(day>=60?8:0)-(orbActive&&!orb?16:0));
}
export function lockedSlots(day,end,begin) {
 if(day<40||day>=70)return [];
 return [...(!end&&!begin?END_SLOTS:[]),...(day>=60&&!begin?BEGIN_SLOTS:[])];
}
export function recipeBook(day) {
 const r=[
 {id:'permadeath:end_relic',name:'Reliquia del Fin',day:40,cost:{'minecraft:shulker_shell':2,'minecraft:diamond_block':1}},
 {id:'permadeath:super_golden_apple_plus',name:'Super Golden Apple +',day:40,cost:{'minecraft:golden_apple':1,'minecraft:gold_ingot':64}},
 {id:'permadeath:hyper_golden_apple_plus',name:'Hyper Golden Apple +',day:40,cost:{'minecraft:golden_apple':day>=60?64:1,'minecraft:gold_block':64}},
 {id:'permadeath:beginning_relic',name:'Reliquia del Comienzo',day:60,cost:{'permadeath:end_relic':1,'minecraft:shulker_shell':4,'minecraft:diamond_block':128}},
 {id:'permadeath:life_orb',name:'Orbe de Vida',day:60,cost:{'minecraft:heart_of_the_sea':1,...Object.fromEntries(['diamond','gold_ingot','bone_block','blaze_rod','end_stone','nether_brick','obsidian','lapis_block'].map(x=>['minecraft:'+x,64]))}},
 // Alternative supply chain for the omitted Java structure/loot generator.
 {id:'permadeath:infernal_netherite_block',name:'Bloque infernal (receta adaptada)',day:40,cost:{'minecraft:netherite_ingot':4,'minecraft:nether_star':1}},
 ];
 for(const part of ['helmet','chestplate','leggings','boots']) {
  r.push({id:'permadeath:netherite_'+part,name:'Netherita Permadeath: '+part,day:25,cost:{['minecraft:netherite_'+part]:1,'minecraft:diamond':4}});
  for(const [tier,material,min] of [['demonic','blaze_rod',30],['scientific','emerald',40],['bomb','gunpowder',40],['pink','amethyst_shard',40]]) r.push({id:`permadeath:${tier}_netherite_${part}`,name:`${tier}: ${part} (adaptada)`,day:min,cost:{['permadeath:netherite_'+part]:1,['minecraft:'+material]:32}});
 }
 return r;
}
export const PHASES = [
 '0–9: muerte permanente, Deathtrain y sueño con un jugador.',
 '10–19: arañas con efectos; hacen falta 4 jugadores dormidos.',
 '20–29: fauna hostil y esqueletos de clase. Desde 25: gigantes.',
 '30–39: End abierto, creepers cargados y enemigos reforzados; sin dormir.',
 '40–49: −4 corazones, espacios sellados, PvP, reliquias y Supernovas.',
 '50–59: Deathtrain UHC, Ultra Ravager y enemigos reforzados.',
 '60–69: −4 corazones más, Orbe de Vida tras 8 h, reliquia del Comienzo y enemigos finales.',
 '70: final de la progresión. Cesan las penalizaciones y las nuevas conversiones.'
];
