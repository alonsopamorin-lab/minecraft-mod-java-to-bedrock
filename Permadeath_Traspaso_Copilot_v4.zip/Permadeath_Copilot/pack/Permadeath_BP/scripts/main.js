import {world,system,ItemStack,EquipmentSlot,ItemLockMode,GameMode,CommandPermissionLevel,CustomCommandStatus,BlockPermutation} from '@minecraft/server';
import {ActionFormData,ModalFormData} from '@minecraft/server-ui';
import {clampDay,dayAt,stormSeconds,totemRule,healthLimit,lockedSlots,recipeBook,PHASES} from './rules.js';
import {ISLANDS} from './islands.js';
const KEY='pd:state_v1', LOCK='permadeath:locked_slot';
let state,day=0,seconds=0,cursor=0,queue=[],queued=new Set(),uiBusy=new Set(),totemPending=new Set(),transit=new Set();
const catSeen=new Map(),hpCaps=new Map(),noticeAt=new Map();
const stats={converted:0,scans:0,errors:0};
const armorSlots=[EquipmentSlot.Head,EquipmentSlot.Chest,EquipmentSlot.Legs,EquipmentSlot.Feet];
const hostileAnimals=new Set(['cow','pig','sheep','chicken','rabbit','wolf','polar_bear']);
const skeletons=['skeleton_warrior','skeleton_tactical','skeleton_infernal','skeleton_assassin','skeleton_nightmare'];
function report(where,e) { stats.errors++; if(stats.errors<12) console.warn(`[Permadeath] ${where}: ${e}`); }
function safe(where,fn){try{return fn();}catch(e){report(where,e);}}
function defer(fn){system.run(()=>safe('evento',fn));}
function save(){world.setDynamicProperty(KEY,JSON.stringify(state));}
function msg(p,s){if(p?.isValid)p.sendMessage('§6[Permadeath] §r'+s);}
function announce(s){world.sendMessage('§6[Permadeath] §r'+s);}
function warn(p,s){if((noticeAt.get(p.id)||0)>system.currentTick)return;noticeAt.set(p.id,system.currentTick+60);msg(p,s);}
function active(p){return p.isValid&&!p.getDynamicProperty('pd:dead')&&[GameMode.Survival,GameMode.Adventure].includes(p.getGameMode());}
function bag(p){return p.getComponent('minecraft:inventory')?.container;}
function counts(p){const c=bag(p),out={};if(c)for(let i=0;i<c.size;i++){const s=c.getItem(i);if(s)out[s.typeId]=(out[s.typeId]||0)+s.amount;}return out;}
function equipped(p){return p.getComponent('minecraft:equippable');}
function fullSet(p,tier){const e=equipped(p);return e&&armorSlots.every((s,i)=>e.getEquipment(s)?.typeId===`permadeath:${tier}_${['helmet','chestplate','leggings','boots'][i]}`);}
function getCap(p,c=counts(p)){
 const apples=Number(p.getDynamicProperty('pd:apples')||0);
 const bonus=(fullSet(p,'infernal_netherite')?10:fullSet(p,'netherite')?8:0)+(Number(p.getDynamicProperty('pd:superTicks')||0)>0?4:0);
 const cap=healthLimit(day,apples,bonus,!!c['permadeath:life_orb'],orbActive());hpCaps.set(p.id,cap);return cap;
}
function orbActive(){return day>=60&&day<70&&(day>60||(state.orbDeadline>0&&Date.now()>=state.orbDeadline));}
function clockReset(n=day){state.baseDay=clampDay(n);state.elapsed=0;state.epoch=Date.now();day=state.baseDay;save();}
function timeText(s){s=Math.max(0,Math.floor(s));return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`;}
function effect(e,id,duration,amp=0){e.addEffect(id,duration,{amplifier:amp,showParticles:false});}
function token(){const x=new ItemStack(LOCK);x.lockMode=ItemLockMode.slot;x.keepOnDeath=true;return x;}
function enforceSlots(p,c){
 const inv=bag(p);if(!inv)return;
 const locks=new Set(active(p)&&state.inventory?lockedSlots(day,!!c['permadeath:end_relic'],!!c['permadeath:beginning_relic']):[]);
 for(let i=0;i<inv.size;i++){
  const x=inv.getItem(i);
  if(!locks.has(i)){if(x?.typeId===LOCK)inv.setItem(i);continue;}
  if(x?.typeId===LOCK)continue;
  if(x){
   let target=-1;for(let j=0;j<inv.size;j++)if(!locks.has(j)&&!inv.getItem(j)){target=j;break;}
   if(target>=0){inv.setItem(target,x);inv.setItem(i);}else{
    // Spawn succeeds before removal. No items silently deleted on a slot transition.
    p.dimension.spawnItem(x,p.location);inv.setItem(i);warn(p,'Espacios sellados: el exceso de objetos quedó a tus pies.');
   }
  }
  inv.setItem(i,token());
 }
}
function totalTotems(p){const c=counts(p);const off=equipped(p)?.getEquipment(EquipmentSlot.Offhand);return (c['minecraft:totem_of_undying']||0)+(off?.typeId==='minecraft:totem_of_undying'?off.amount:0);}
function consumeTotems(p,n){
 const eq=equipped(p),off=eq?.getEquipment(EquipmentSlot.Offhand);
 if(n>0&&off?.typeId==='minecraft:totem_of_undying'){eq.setEquipment(EquipmentSlot.Offhand);n--;}
 const inv=bag(p);if(!inv)return;
 for(let i=0;i<inv.size&&n>0;i++){const s=inv.getItem(i);if(s?.typeId==='minecraft:totem_of_undying'){const used=Math.min(s.amount,n);n-=used;if(s.amount===used)inv.setItem(i);else{s.amount-=used;inv.setItem(i,s);}}}
}
function inspectTotem(p,previous){
 if(!p.isValid||day>=70||!state.totems||!active(p))return;
 const now=totalTotems(p),health=p.getComponent('minecraft:health');
 // Observe actual native consumption, not an estimated lethal hit before armor/shield mitigation.
 if(previous-now!==1||!health||health.currentValue<=0||!p.getEffect('regeneration')||!p.getEffect('fire_resistance'))return;
 const rule=totemRule(day);consumeTotems(p,Math.min(rule.count-1,now));
 if(Math.random()<rule.failure){
  consumeTotems(p,2);announce(`§cEl tótem de ${p.name} ha fallado.`);p.kill();
 }else msg(p,`Tótem activado. Coste: hasta ${rule.count}; fallo: ${Math.round(rule.failure*100)}%.`);
}
function applyPlayer(p){
 const c=counts(p);enforceSlots(p,c);
 const superTicks=Number(p.getDynamicProperty('pd:superTicks')||0);if(superTicks>0)p.setDynamicProperty('pd:superTicks',Math.max(0,superTicks-20));
 if(p.getDynamicProperty('pd:dead')||state.dead.includes(p.name)){if(p.getGameMode()!==GameMode.Spectator)p.setGameMode(GameMode.Spectator);return;}
 if(!active(p))return;
 const cap=getCap(p,c),h=p.getComponent('minecraft:health');
 // Stable API cannot write max-health. Health Boost raises the container; cap enforces exact HP.
 if(cap>20)effect(p,'health_boost',80,Math.ceil((cap-20)/4)-1);
 else if(p.getDynamicProperty('pd:boostOwned'))p.removeEffect('health_boost');
 p.setDynamicProperty('pd:boostOwned',cap>20);
 if(h&&h.currentValue>cap)h.setCurrentValue(cap);
 if(fullSet(p,'infernal_netherite'))effect(p,'resistance',60,0);
 if(day>=40&&day<70){
  const below=p.dimension.getBlock({x:Math.floor(p.location.x),y:Math.floor(p.location.y)-1,z:Math.floor(p.location.z)});
  if(below?.typeId==='minecraft:bedrock')effect(p,'wither',80,0);
 }
 if(!p.getDynamicProperty('pd:nohud'))p.onScreenDisplay.setActionBar(`§6Permadeath §fDía ${day}/70 §7| §cVida ${Math.ceil(h?.currentValue||0)}/${cap}`+(state.storm>0?` §7| §9Deathtrain ${timeText(state.storm)}`:'')+(day>=60&&day<70?` §7| §dOrbe ${orbActive()?'activo':timeText((state.orbDeadline-Date.now())/1000)}`:''));
 if(day<30&&p.dimension.id==='minecraft:the_end'&&!transit.has(p.id)){
  const spawn=world.getDefaultSpawnLocation();p.teleport({x:spawn.x+.5,y:spawn.y,z:spawn.z+.5},{dimension:world.getDimension('overworld')});effect(p,'slow_falling',200);msg(p,'El End se abre en el día 30.');
 }
 if(day>=55&&day<70&&!p.getDynamicProperty('pd:medal')){
  const inv=bag(p);if(inv?.emptySlotsCount>0){const medal=new ItemStack('minecraft:totem_of_undying');medal.nameTag='§6Medalla de Superviviente';medal.setDynamicProperty('pd:medal',true);inv.addItem(medal);p.setDynamicProperty('pd:medal',true);msg(p,'Recibes una Medalla de Superviviente (tótem con protección contra fallo).');}
 }
}
function refreshWorld(){
 world.gameRules.pvp=day>=40&&day<70;
 world.gameRules.naturalRegeneration=!(state.storm>0&&day>=50&&day<70);
 world.gameRules.playersSleepingPercentage=(day>=20&&day<70)||state.storm>0?101:day>=10&&day<20?101:0;
 if(state.storm>0)world.getDimension('overworld').setWeather('Thunder',1200);
}
function pulse(){
 if(!state)return;
 seconds++;
 if(!state.paused&&state.clock==='play'&&world.getAllPlayers().some(active))state.elapsed++;
 const next=dayAt(state,Date.now());
 if(next!==day){day=next;announce(`§eDía ${day}. ${PHASES[Math.min(7,Math.floor(day/10))]}`);if(day===60&&!state.orbDeadline)state.orbDeadline=Date.now()+8*3600000;if(day>60&&day<70&&!state.orbDeadline)state.orbDeadline=Date.now();refreshWorld();save();}
 if(day>=70&&state.storm>0){state.storm=0;world.getDimension('overworld').setWeather('Clear',600);refreshWorld();}
 if(state.storm>0){state.storm=Math.max(0,state.storm-1);if(state.storm===0){world.getDimension('overworld').setWeather('Clear',600);refreshWorld();announce('El Deathtrain ha terminado.');}}
 const players=world.getAllPlayers();for(const p of players)safe('jugador',()=>applyPlayer(p));
 if(day>=10&&day<20&&state.storm===0&&players.filter(p=>active(p)&&p.isSleeping&&p.dimension.id==='minecraft:overworld').length>=4)world.setTimeOfDay(0);
 if((day<10||day>=70)&&state.storm===0&&players.some(p=>active(p)&&p.isSleeping&&p.dimension.id==='minecraft:overworld'))world.setTimeOfDay(0);
 if(seconds%20===0){refreshWorld();save();}
 if(seconds%60===0){noticeAt.clear();for(const [id,t]of catSeen)if(system.currentTick-t>1200)catSeen.delete(id);for(const id of hpCaps.keys())if(!players.some(p=>p.id===id))hpCaps.delete(id);}
}
function protectedMob(e){
 if(e.nameTag||e.hasTag('pd:preserve')||e.getComponent('minecraft:is_baby')||e.getComponent('minecraft:is_tamed'))return true;
 if(e.getComponent('minecraft:tameable')?.isTamed)return true;
 return false;
}
function replacement(e){
 if(day<20||day>=70||protectedMob(e))return;
 const t=e.typeId.replace('minecraft:','');
 if(hostileAnimals.has(t))return 'hostile_'+t;
 if(t==='skeleton')return day>=60?'demonic_skeleton':skeletons[Math.floor(Math.random()*skeletons.length)];
 if(t==='wither_skeleton'&&day>=60)return 'wither_emperor';
 if(t==='ravager'&&day>=50)return 'ultra_ravager';
 if(t==='zombie'&&day>=25&&Math.random()<.05)return 'giant_zombie';
 if(t==='slime'&&day>=25)return 'giga_slime';
 if(t==='magma_cube'&&day>=25)return 'giga_magma';
 if(t==='cave_spider'&&day>=60)return 'abyssal_spider';
}
function processMob(e){
 if(!e.isValid||day>=70)return;
 if(!world.getAllPlayers().some(p=>active(p)&&p.dimension.id===e.dimension.id&&distance(p.location,e.location)<=state.radius))return;
 const t=e.typeId,phase=day>=60?6:day>=50?5:day>=40?4:day>=30?3:day>=25?2.5:day>=20?2:day>=10?1:0;
 if(t.startsWith('permadeath:')){
  const wide=state.radius>44;if(e.getDynamicProperty('pd:wide')!==wide){e.triggerEvent(wide?'pd:wide':'pd:compact');e.setDynamicProperty('pd:wide',wide);}
  if(state.storm>0&&day>=40)effect(e,'strength',80,day>=60?2:day>=50?1:0);
  return;
 }
 if(!t.startsWith('minecraft:')||!e.getComponent('minecraft:health')||t==='minecraft:player')return;
 const old=e.getDynamicProperty('pd:phase');
 if(old!==phase){
  const kind=replacement(e);
  if(kind){
   if(e.dimension.getEntities({location:e.location,maxDistance:44,families:['pd_mob'],closest:48}).length>=48)return;
   // One-for-one conversion. Spawn errors leave the original intact; no extra ambient spawn loop.
   const dim=e.dimension,pos=e.location;const n=dim.spawnEntity('permadeath:'+kind,pos);
   try{n.setRotation(e.getRotation());n.setDynamicProperty('pd:phase',phase);e.remove();}catch(err){n.remove();throw err;}
   stats.converted++;return;
  }
  if(t==='minecraft:creeper'&&day>=30){e.triggerEvent('minecraft:become_charged');}
  e.setDynamicProperty('pd:phase',phase);
 }
 if(day>=10&&(t==='minecraft:spider'||t==='minecraft:cave_spider')){
  let chosen=e.getDynamicProperty('pd:spiderEffect');if(!chosen){chosen=['speed','strength','resistance','regeneration','invisibility'][Math.floor(Math.random()*5)];e.setDynamicProperty('pd:spiderEffect',chosen);}
  effect(e,chosen,100,day>=40?2:day>=20?1:0);
 }
 if(day>=30&&['minecraft:zombie','minecraft:enderman','minecraft:blaze','minecraft:phantom','minecraft:witch','minecraft:ghast','minecraft:shulker','minecraft:creeper'].includes(t)){
  effect(e,'resistance',100,day>=60?2:day>=40?1:0);effect(e,'speed',100,day>=50?1:0);
  if(t==='minecraft:witch')effect(e,'regeneration',100,day>=40?2:0);
 }
 if(state.storm>0&&day>=40&&['minecraft:zombie','minecraft:spider','minecraft:enderman','minecraft:blaze','minecraft:phantom'].includes(t))effect(e,'strength',100,day>=60?2:day>=50?1:0);
 if(day>=40&&t==='minecraft:cat'&&!protectedMob(e)){
  const oldTicks=Number(e.getDynamicProperty('pd:catTicks')||0),last=catSeen.get(e.id);catSeen.set(e.id,system.currentTick);
  const elapsed=last===undefined?1:Math.min(20,Math.max(0,system.currentTick-last));const ticks=oldTicks+elapsed;e.setDynamicProperty('pd:catTicks',ticks);
  if(oldTicks===0)for(const p of e.dimension.getPlayers({location:e.location,maxDistance:24}))msg(p,'§c¡Gato Supernova cerca! Aléjate; su cuenta avanza mientras está activo.');
  if(ticks>=200){const dim=e.dimension,pos=e.location;e.remove();dim.createExplosion(pos,day>=60?5:3,{breaksBlocks:state.destruction,causesFire:state.destruction});}
 }
}
function scan(){
 if(!state||day<10||day>=70)return;
 const players=world.getAllPlayers().filter(active);if(!players.length)return;
 const p=players[cursor++%players.length];
 // One bounded native query per half second; at most 8 entity updates each tick.
 const entities=p.dimension.getEntities({location:p.location,maxDistance:state.radius,excludeTypes:['minecraft:player','minecraft:item','minecraft:xp_orb'],closest:96});
 stats.scans++;
 for(const e of entities){if(queue.length>=192)break;if(!queued.has(e.id)){queue.push(e);queued.add(e.id);}}
}
function drain(){for(let i=0;i<8&&queue.length;i++){const e=queue.shift();queued.delete(e.id);safe('criatura',()=>processMob(e));}}
function validCraft(p){return active(p)&&!transit.has(p.id);}
function craft(p,r){
 if(!validCraft(p)||day<r.day)return msg(p,`Disponible desde el día ${r.day}.`);
 const inv=bag(p),c=counts(p);if(!inv)return;
 if(Object.entries(r.cost).some(([id,n])=>(c[id]||0)<n))return msg(p,'Faltan materiales. No se ha consumido nada.');
 // Dry-run using cloned slots, then commit the complete transaction synchronously.
 const slots=Array.from({length:inv.size},(_,i)=>inv.getItem(i));
 for(const [id,n]of Object.entries(r.cost)){let left=n;for(let i=0;i<slots.length&&left;i++){const s=slots[i];if(s?.typeId!==id)continue;const use=Math.min(left,s.amount);left-=use;if(use===s.amount)slots[i]=undefined;else s.amount-=use;}}
 const dest=slots.findIndex(x=>!x);if(dest<0)return msg(p,'Libera un espacio antes de fabricar.');
 const output=new ItemStack(r.id);slots[dest]=output;
 for(let i=0;i<slots.length;i++)inv.setItem(i,slots[i]);msg(p,`Fabricado: ${r.name}.`);
}
async function forge(p){
 const recipes=recipeBook(day);const f=new ActionFormData().title('Forja Permadeath').body('Consume materiales de tu inventario. Las recetas con “adaptada” sustituyen botín o sistemas de Java.');
 for(const r of recipes)f.button(`${day<r.day?'§8':'§f'}${r.name}\nDía ${r.day}`);
 const res=await f.show(p);if(res.canceled)return;const r=recipes[res.selection];if(!r)return;
 const cost=Object.entries(r.cost).map(([id,n])=>`${n} × ${id.replace('minecraft:','').replace('permadeath:','')}`).join('\n');
 const confirm=await new ActionFormData().title(r.name).body(`Día requerido: ${r.day}\n\n${cost}\n\nLos materiales se consumen al fabricar.`).button('Fabricar').button('Volver').show(p);
 if(!confirm.canceled&&confirm.selection===0)craft(p,r);
}
async function settings(p){
 if(!p.hasTag('pd_admin'))return;
 const f=new ModalFormData().title('Ajustes de Permadeath').dropdown('Reloj de progresión',['Días reales (cuenta cerrado)','Tiempo jugado (pausa sin supervivientes)'],{defaultValueIndex:state.clock==='real'?0:1}).textField('Minutos por día (20–10080)','1440',{defaultValue:String(state.daySeconds/60)}).textField('Día actual (0–70)','0',{defaultValue:String(day)}).toggle('Pausar progresión',{defaultValue:state.paused}).dropdown('Radio de trabajo: usa 44 con simulación 4',['44 bloques · móvil / simulación 4','96 bloques · simulación 6 o más'],{defaultValueIndex:state.radius===44?0:1}).toggle('Sellar espacios del inventario',{defaultValue:state.inventory}).toggle('Reglas de fallo y coste de tótems',{defaultValue:state.totems}).toggle('Supernovas destruyen bloques',{defaultValue:state.destruction});
 const r=await f.show(p);if(r.canceled||!p.hasTag('pd_admin'))return;
 const [clock,minutes,newDay,paused,radius,inventory,totems,destruction]=r.formValues;
 const m=Number(minutes),d=Number(newDay);if(!Number.isFinite(m)||m<20||m>10080||!Number.isInteger(d)||d<0||d>70)return msg(p,'Valores inválidos; no se cambió nada.');
 state.clock=clock===0?'real':'play';state.daySeconds=m*60;state.paused=paused;state.radius=radius===0?44:96;state.inventory=inventory;state.totems=totems;state.destruction=destruction;
 clockReset(d);if(day>=60&&day<70&&!state.orbDeadline)state.orbDeadline=Date.now()+(day===60?8*3600000:0);refreshWorld();msg(p,'Ajustes guardados. El radio no cambia la distancia de simulación del mundo.');
}
async function admin(p){
 if(!p.hasTag('pd_admin'))return;
 const r=await new ActionFormData().title('Administración').body('Las resurrecciones son excepciones manuales al reto.').button('Ajustes').button('Terminar Deathtrain').button('Revivir jugador conectado').show(p);
 if(r.canceled||!p.hasTag('pd_admin'))return;
 if(r.selection===0)return settings(p);
 if(r.selection===1){state.storm=0;save();world.getDimension('overworld').setWeather('Clear',600);refreshWorld();msg(p,'Deathtrain terminado.');}
 if(r.selection===2){const dead=world.getAllPlayers().filter(x=>x.getDynamicProperty('pd:dead'));const f=new ActionFormData().title('Revivir').body('Selecciona un jugador');if(!dead.length)return msg(p,'No hay jugadores eliminados conectados.');dead.forEach(x=>f.button(x.name));const x=await f.show(p);if(x.canceled||!p.hasTag('pd_admin'))return;const target=dead[x.selection];if(!target?.isValid)return;state.dead=state.dead.filter(name=>name!==target.name);save();target.setDynamicProperty('pd:dead',false);target.setGameMode(GameMode.Survival);msg(target,'Un administrador te ha revivido.');}
}
async function menu(p){
 if(!state||!p.isValid||uiBusy.has(p.id))return;uiBusy.add(p.id);
 try{
  const f=new ActionFormData().title('§4Permadeath §rv.4 · Bedrock').body(`Día ${day}/70 · ${state.paused?'PAUSADO':state.clock==='real'?'reloj real':'tiempo jugado'}\n${PHASES[Math.min(7,Math.floor(day/10))]}\n\nAdaptación de prueba para móvil · Bedrock 26.52. Revisa la guía antes de iniciar una partida definitiva.`).button('Forja y recetas').button('Reglas y diferencias').button('Expedición The Beginning').button('Mostrar / ocultar marcador');
  if(p.hasTag('pd_admin'))f.button('Administración');
  const r=await f.show(p);if(r.canceled)return;
  if(r.selection===0)await forge(p);
  if(r.selection===1)await new ActionFormData().title('Reglas').body(PHASES.join('\n\n')+'\n\nMuerte: espectador permanente. La vida máxima efectiva aparece en el marcador; los corazones vacíos pueden seguir visibles. The Beginning es una arena en el End. Las criaturas nombradas, bebés y mascotas no se sustituyen. No se reproduce toda la IA Java.\n\nOriginal: Serthekiller. Sin afiliación con Mojang.').button('Cerrar').show(p);
  if(r.selection===2)await beginningMenu(p);
  if(r.selection===3)p.setDynamicProperty('pd:nohud',!p.getDynamicProperty('pd:nohud'));
  if(r.selection===4)await admin(p);
 }catch(e){report('menú',e);msg(p,'No se pudo abrir el menú. Cierra el chat y vuelve a intentarlo.');}finally{uiBusy.delete(p.id);}
}
const CENTER={x:8192.5,y:184,z:8192.5};
let buildBusy=false;
function inBeginning(p){return p.dimension.id==='minecraft:the_end'&&Math.abs(p.location.x-CENTER.x)<70&&Math.abs(p.location.z-CENTER.z)<70&&p.location.y>130;}
function distance(a,b){return Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);}
const waitTicks=n=>new Promise(resolve=>system.runTimeout(resolve,n));
async function beginningMenu(p){
 if(!active(p))return msg(p,'Solo disponible para supervivientes.');
 if(inBeginning(p)){
  const r=await new ActionFormData().title('The Beginning').body('Zona adaptada en el End. Volverás al punto desde el que entraste.').button('Regresar').button('Seguir explorando').show(p);
  if(!r.canceled&&r.selection===0)await returnFromBeginning(p);return;
 }
 if(day<40)return msg(p,'The Beginning se abre en el día 40.');
 if(state.storm>0)return msg(p,'El portal está cerrado durante el Deathtrain.');
 if(!counts(p)['permadeath:end_relic']&&!counts(p)['permadeath:beginning_relic'])return msg(p,'Lleva una Reliquia del Fin o del Comienzo para entrar.');
 const r=await new ActionFormData().title('Expedición The Beginning').body('Cinco islas del mod, reconstruidas en una zona del End. No es una dimensión nueva.\n\nRegreso: /pd:menu → Expedición, o agacharte e interactuar con la mesa central.\n\nLa muerte sigue siendo permanente.').button('Entrar').button('Cancelar').show(p);
 if(r.canceled||r.selection!==0||!active(p)||state.storm>0||day<40)return;
 await enterBeginning(p);
}
async function enterBeginning(p){
 const back={dimension:p.dimension.id,...p.location};p.setDynamicProperty('pd:return',JSON.stringify(back));transit.add(p.id);
 try{
  p.teleport(CENTER,{dimension:world.getDimension('the_end')});effect(p,'slow_falling',300);
  let ready=false;
  for(let attempt=0;attempt<60;attempt++){
   await waitTicks(2);if(!p.isValid)throw Error('Jugador desconectado');p.teleport(CENTER);
   const dim=p.dimension;
   try{
    const blocks=[];
    for(let x=8188;x<=8196;x++)for(let z=8188;z<=8196;z++){const b=dim.getBlock({x,y:182,z});if(!b)throw Error('Zona aún no cargada');blocks.push(b);}
    for(const b of blocks)if(b.isAir)b.setType('minecraft:purpur_block');
    const table=dim.getBlock({x:8192,y:183,z:8190});if(!table)throw Error('Zona aún no cargada');if(table.isAir)table.setType('minecraft:crafting_table');
    ready=true;break;
   }catch(e){if(attempt===59)throw e;}
  }
  if(!ready)throw Error('No se pudo cargar el destino');
  p.teleport(CENTER);msg(p,'The Beginning: agáchate y usa la mesa central para regresar. Las islas se construyen al acercarte.');
 }catch(e){report('viaje',e);if(p.isValid){p.teleport({x:back.x,y:back.y,z:back.z},{dimension:world.getDimension(back.dimension)});msg(p,'No se pudo preparar el destino. Has regresado.');}}
 finally{transit.delete(p.id);}
}
async function returnFromBeginning(p){
 const raw=p.getDynamicProperty('pd:return');if(!raw)return msg(p,'No hay punto de retorno guardado; usa un portal normal del End.');
 const b=JSON.parse(raw);transit.add(p.id);
 try{p.teleport({x:b.x,y:b.y,z:b.z},{dimension:world.getDimension(b.dimension)});effect(p,'slow_falling',200);await waitTicks(20);}finally{transit.delete(p.id);}
}
function* constructIsland(index){
 const island=ISLANDS[index],dim=world.getDimension('the_end');let completed=true;
 try{
  for(const [x,y,z,id,states]of island.blocks){
   // Never force-load a chunk or overwrite a non-air block.
   let block;try{block=dim.getBlock({x,y,z});}catch{completed=false;break;}
   if(!block){completed=false;break;}
   if(block.isAir)block.setPermutation(BlockPermutation.resolve(id,states));
   yield;
  }
  if(completed){
   for(const [x,y,z]of island.chests){const inv=dim.getBlock({x,y,z})?.getComponent('minecraft:inventory')?.container;if(inv&&inv.emptySlotsCount===inv.size){inv.addItem(new ItemStack('minecraft:diamond_block',4));inv.addItem(new ItemStack('minecraft:shulker_shell',2));inv.addItem(new ItemStack('minecraft:golden_apple',4));}}
   state.islands[index]=true;save();
  }
 }catch(e){report('isla',e);}finally{buildBusy=false;}
}
function beginningPulse(){
 if(!state||day<40||day>=70)return;
 const ps=world.getAllPlayers().filter(p=>active(p)&&inBeginning(p));if(!ps.length)return;
 if(!buildBusy){const i=ISLANDS.findIndex((s,i)=>!state.islands[i]&&ps.some(p=>distance(p.location,{x:s.center[0],y:s.center[1],z:s.center[2]})<30));if(i>=0){buildBusy=true;system.runJob(constructIsland(i));}}
 const dim=world.getDimension('the_end');
 // Original spawners replaced by bounded encounter points, checked every ten seconds.
 if(seconds%10!==0)return;
 const local=dim.getEntities({location:CENTER,maxDistance:80,families:['pd_mob']});if(local.length>=12)return;
 for(let i=0;i<ISLANDS.length;i++){
  if(!state.islands[i])continue;
  for(const [x,y,z]of ISLANDS[i].spawners){
   const pos={x:x+.5,y:y+1,z:z+.5};const near=ps.map(p=>distance(p.location,pos));
   if(Math.min(...near)<24||Math.min(...near)>40)continue;
   const a=dim.getBlock(pos),b=dim.getBlock({x,y:y+2,z});if(!a?.isAir||!b?.isAir)continue;
   dim.spawnEntity(day>=60?'permadeath:abyssal_spider':'permadeath:skeleton_nightmare',pos);return;
  }
 }
}
// Public menu and operator-only administrator access. No chat interception or beta APIs.
system.beforeEvents.startup.subscribe(ev=>{
 ev.customCommandRegistry.registerCommand({name:'pd:menu',description:'Abrir Permadeath',permissionLevel:CommandPermissionLevel.Any,cheatsRequired:false},origin=>{
  const p=origin.sourceEntity;if(p?.typeId!=='minecraft:player')return {status:CustomCommandStatus.Failure,message:'Solo jugadores.'};
  system.runTimeout(()=>menu(p),5);return {status:CustomCommandStatus.Success};
 });
 ev.customCommandRegistry.registerCommand({name:'pd:admin',description:'Abrir administración de Permadeath',permissionLevel:CommandPermissionLevel.GameDirectors,cheatsRequired:true},origin=>{
  const p=origin.sourceEntity;if(p?.typeId!=='minecraft:player')return {status:CustomCommandStatus.Failure,message:'Solo jugadores.'};
  defer(()=>{p.addTag('pd_admin');system.runTimeout(()=>menu(p),5);});return {status:CustomCommandStatus.Success};
 });
 ev.customCommandRegistry.registerCommand({name:'pd:status',description:'Diagnóstico de Permadeath',permissionLevel:CommandPermissionLevel.Any,cheatsRequired:false},origin=>{
  const p=origin.sourceEntity;defer(()=>msg(p,`v.4 | día ${day} | radio ${state?.radius} | cola ${queue.length}/192 | conversiones ${stats.converted} | errores ${stats.errors}`));return {status:CustomCommandStatus.Success};
 });
});
world.afterEvents.worldLoad.subscribe(()=>safe('inicio',()=>{
 const raw=world.getDynamicProperty(KEY);
 state=raw?JSON.parse(raw):{baseDay:0,epoch:Date.now(),elapsed:0,clock:'real',daySeconds:86400,paused:false,storm:0,orbDeadline:0,radius:44,inventory:true,totems:true,destruction:true,islands:[],dead:[]};
 state.islands??=[];state.dead??=[];day=dayAt(state,Date.now());
 if(day>=60&&day<70&&!state.orbDeadline)state.orbDeadline=Date.now()+(day===60?28800000:0);
 refreshWorld();save();announce('§aComplemento cargado. Agáchate y usa una mesa de trabajo para abrir el menú. /pd:status muestra el diagnóstico.');
}));
world.beforeEvents.playerInteractWithBlock.subscribe(ev=>{
 if(!state)return;const p=ev.player;
 if(ev.block.typeId==='minecraft:crafting_table'&&p.isSneaking){ev.cancel=true;defer(()=>menu(p));return;}
 if(ev.block.typeId.endsWith('_bed')||ev.block.typeId==='minecraft:bed'){
  if((day>=20&&day<70)||state.storm>0){ev.cancel=true;defer(()=>warn(p,'No se puede dormir durante esta fase o durante el Deathtrain.'));}
 }
});
world.afterEvents.playerSpawn.subscribe(ev=>defer(()=>{
 const p=ev.player;if(!state)return;
 if(state.dead.includes(p.name))p.setDynamicProperty('pd:dead',true);
 if(p.getDynamicProperty('pd:dead'))p.setGameMode(GameMode.Spectator);
 if(ev.initialSpawn){msg(p,'Permadeath v.4: agáchate y usa una mesa de trabajo. Día '+day+'.');if(p.getDynamicProperty('pd:return')&&inBeginning(p))effect(p,'slow_falling',200);}
}));
world.afterEvents.entityDie.subscribe(ev=>safe('muerte',()=>{
 const p=ev.deadEntity;if(!state||p.typeId!=='minecraft:player'||day>=70)return;
 const name=p.name;if(state.dead.includes(name))return;
 state.dead.push(name);state.storm+=stormSeconds(day);save();safe('marca de muerte',()=>p.setDynamicProperty('pd:dead',true));refreshWorld();
 announce(`§c${name} ha muerto. §7Queda eliminado; Deathtrain +${timeText(stormSeconds(day))}.`);
 for(const other of world.getAllPlayers()){if(day>=30)safe('sonido',()=>other.playSound('permadeath.death'));safe('título',()=>other.onScreenDisplay.setTitle('§4PERMADEATH',{subtitle:'§c'+name+' ha muerto',stayDuration:80,fadeInDuration:10,fadeOutDuration:20}));}
}));
world.beforeEvents.entityHurt.subscribe(ev=>{
 const p=ev.hurtEntity;if(!state||p.typeId!=='minecraft:player')return;
 const shooter=ev.damageSource?.damagingEntity;if(ev.damageSource?.damagingProjectile&&shooter?.typeId.startsWith('permadeath:')){const power={'permadeath:skeleton_warrior':1.5,'permadeath:skeleton_tactical':1.5,'permadeath:skeleton_assassin':2,'permadeath:skeleton_nightmare':2.5,'permadeath:demonic_skeleton':3}[shooter.typeId];if(power&&day<70)ev.damage*=power;}
 if(transit.has(p.id)){ev.cancel=true;return;}
 if(!state.totems||!active(p)||day>=70||totemPending.has(p.id))return;
 const eq=equipped(p);const a=eq?.getEquipment(EquipmentSlot.Mainhand),b=eq?.getEquipment(EquipmentSlot.Offhand);
 if(a?.typeId!=='minecraft:totem_of_undying'&&b?.typeId!=='minecraft:totem_of_undying')return;
 const previous=totalTotems(p),medal=!!(a?.typeId==='minecraft:totem_of_undying'?a.getDynamicProperty('pd:medal'):b?.getDynamicProperty('pd:medal'));
 totemPending.add(p.id);defer(()=>{
  try{if(medal&&p.isValid&&previous-totalTotems(p)===1&&p.getEffect('regeneration')&&p.getEffect('fire_resistance')){consumeTotems(p,totemRule(day).count-1);msg(p,'La Medalla de Superviviente te ha protegido.');}else inspectTotem(p,previous);}finally{totemPending.delete(p.id);}
 });
});
world.beforeEvents.entityHeal.subscribe(ev=>{
 const p=ev.healedEntity;if(!state||p.typeId!=='minecraft:player'||!active(p))return;
 const h=p.getComponent('minecraft:health');const cap=hpCaps.get(p.id);if(h&&cap!==undefined){ev.healing=Math.max(0,Math.min(ev.healing,cap-h.currentValue));if(ev.healing===0)ev.cancel=true;}
});
world.beforeEvents.itemUse.subscribe(ev=>{
 if(!state)return;const p=ev.source,id=ev.itemStack.typeId;
 if(id==='permadeath:hyper_golden_apple_plus'){
  const n=Number(p.getDynamicProperty('pd:apples')||0);
  if(day<40||n>=(day<60?1:2)){ev.cancel=true;defer(()=>msg(p,'Hyper Apple: desde día 40; máximo 1 antes del 60 y 2 en total.'));}
 }
 if(id==='permadeath:super_golden_apple_plus'&&day<40){ev.cancel=true;defer(()=>msg(p,'Disponible desde el día 40.'));}
});
world.afterEvents.itemCompleteUse.subscribe(ev=>safe('consumible',()=>{
 const p=ev.source,id=ev.itemStack.typeId;if(!state)return;
 if(id==='permadeath:hyper_golden_apple_plus'){
  const n=Number(p.getDynamicProperty('pd:apples')||0);if(day>=40&&n<(day<60?1:2)){p.setDynamicProperty('pd:apples',n+1);getCap(p);msg(p,'Vida permanente +2 corazones.');}
 }
 if(id==='permadeath:super_golden_apple_plus'){p.setDynamicProperty('pd:superTicks',6000);applyPlayer(p);}
 if(id==='minecraft:milk_bucket')p.setDynamicProperty('pd:superTicks',0);
}));
world.afterEvents.entityHurt.subscribe(ev=>safe('golpe especial',()=>{
 if(!state||day>=70)return;const p=ev.hurtEntity,a=ev.damageSource.damagingEntity;if(p.typeId!=='minecraft:player'||!a)return;
 if(a.typeId==='permadeath:wither_emperor'||a.typeId==='permadeath:skeleton_nightmare')effect(p,'wither',100,1);
 if(a.typeId==='permadeath:abyssal_spider')effect(p,'poison',160,1);
}));
world.afterEvents.playerLeave.subscribe(ev=>{uiBusy.delete(ev.playerId);hpCaps.delete(ev.playerId);noticeAt.delete(ev.playerId);transit.delete(ev.playerId);totemPending.delete(ev.playerId);});
system.runInterval(()=>safe('reloj',pulse),20);
system.runInterval(()=>safe('consulta local',scan),10);
system.runInterval(drain,1);
system.runInterval(()=>safe('expedición',beginningPulse),20);
