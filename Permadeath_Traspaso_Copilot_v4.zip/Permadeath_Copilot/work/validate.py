from pathlib import Path
import json,uuid,zipfile,subprocess
from PIL import Image
root=Path('pack');errors=[];docs={};ident=set();uidset=set()
for p in root.rglob('*.json'):
 try:docs[p]=json.loads(p.read_text())
 except Exception as e:errors.append(f'{p}: {e}')
for p,d in docs.items():
 for typ in ['minecraft:item','minecraft:block','minecraft:entity']:
  if typ in d:ident.add(d[typ]['description']['identifier'])
 if p.name=='manifest.json':
  for x in [d['header'],*d['modules']]:
   u=x['uuid'];uuid.UUID(u)
   if u in uidset:errors.append('duplicate uuid '+u)
   uidset.add(u)
  if 'script' in [x['type'] for x in d['modules']]:
   assert (p.parent/'scripts/main.js').exists()
  assert d['header']['min_engine_version']==[1,26,50]
for p in root.rglob('*.png'):
 try:
  with Image.open(p) as im:im.verify()
 except Exception as e:errors.append(f'{p}: {e}')
for p,d in docs.items():
 if 'minecraft:recipe_shaped' in d:
  r=d['minecraft:recipe_shaped'];ids=[v['item']for v in r['key'].values()]+[r['result']['item']]
  for x in ids:
   if x.startswith('permadeath:') and x not in ident:errors.append('missing item '+x)
 if 'minecraft:client_entity' in d:
  desc=d['minecraft:client_entity']['description'];geo=desc['geometry']['default']
  found=any(geo==g['description']['identifier']for data in docs.values() if isinstance(data,dict) for g in data.get('minecraft:geometry',[]))
  if not found:found=any(geo==key.split(':')[0] for data in docs.values() if isinstance(data,dict) for key in data if key.startswith('geometry.'))
  if not found:errors.append('missing geometry '+geo)
 if p.name=='item_texture.json':
  for name,x in d['texture_data'].items():
   if not (Path('pack/Permadeath_RP')/(x['textures']+'.png')).exists():errors.append('missing texture '+name)
 if 'minecraft:entity' in d:
  e=d['minecraft:entity'];loot=e['components'].get('minecraft:loot',{}).get('table')
  if loot and not (Path('pack/Permadeath_BP')/loot).exists():errors.append('missing loot '+loot)
for p in root.rglob('*.js'):
 r=subprocess.run(['node','--input-type=module','--check'],input=p.read_text(),capture_output=True,text=True)
 if r.returncode:errors.append(r.stderr)
print(f'{len(docs)} JSON documents; {len(list(root.rglob("*.png")))} PNGs; {len(ident)} custom identifiers; {len(list(root.rglob("*.js")))} JS modules')
assert not errors,errors
print('Static validation passed. External vanilla assets and Bedrock schema/runtime remain unverified.')
