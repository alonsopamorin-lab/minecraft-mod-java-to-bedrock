import assert from 'node:assert/strict';
import * as m from './mock.mjs';
import * as r from './runtime-test.mjs';
m.subscriptions['after:worldLoad']();
const p=m.player('Audit');let count=0;
for(const day of [0,10,20,25,30,40,50,60,69,70]){
 r.setDay(day);r.peek().state.storm=3600;
 for(const type of ['breeze','bogged','armadillo','allay','warden','villager','unknown_future_mob']){
  const forbidden=()=>{throw Error('Unexpected mutation: '+type+' day '+day)};
  const props=new Map();
  const e={id:type,typeId:'minecraft:'+type,isValid:true,nameTag:'',location:p.location,dimension:{id:p.dimension.id,getEntities:()=>[],spawnEntity:forbidden},hasTag:()=>false,getComponent:k=>k==='minecraft:health'?{currentValue:20,setCurrentValue:forbidden}:undefined,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),addEffect:forbidden,remove:forbidden,triggerEvent:forbidden};
  r.processMob(e);count++;
 }
}
console.log('PASS: '+count+' exclusion cases: no effects, conversion, health changes or entity events. Mock runtime only.');
