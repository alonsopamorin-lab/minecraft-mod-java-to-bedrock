import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import * as m from './mock.mjs';
const rulesURL=pathToFileURL(process.cwd()+'/pack/Permadeath_BP/scripts/rules.js').href;
const rules=await import(rulesURL);
let src=fs.readFileSync('pack/Permadeath_BP/scripts/main.js','utf8').replaceAll("'@minecraft/server'","'./mock.mjs'").replaceAll("'@minecraft/server-ui'","'./mock.mjs'").replace("'./rules.js'",JSON.stringify(rulesURL)).replace("'./islands.js'",JSON.stringify(pathToFileURL(process.cwd()+'/pack/Permadeath_BP/scripts/islands.js').href));
src+='\nexport {craft,enforceSlots,applyPlayer,inspectTotem,admin,processMob,scan,drain,stats}; export const peek=()=>({state,day,queue}); export function setDay(n){clockReset(n);}';
fs.writeFileSync('work/runtime-test.mjs',src);
const r=await import('./runtime-test.mjs');
m.subscriptions.startup({customCommandRegistry:{registerCommand:(spec,fn)=>{m.commands[spec.name]={spec,fn};}}});
assert.equal(m.commands['pd:admin'].spec.permissionLevel,m.CommandPermissionLevel.GameDirectors);
m.subscriptions['after:worldLoad']();
const p=m.player('Prueba'),{ItemStack:I}=m;
let passed=0;function test(name,fn){fn();passed++;console.log('PASS',name);}
test('real clock advances offline; play clock and pause do not',()=>{
 const s={baseDay:3,epoch:0,elapsed:120,clock:'real',daySeconds:86400,paused:false};assert.equal(rules.dayAt(s,86400000*3),6);assert.equal(rules.dayAt({...s,clock:'play'},86400000*3),3);assert.equal(rules.dayAt({...s,paused:true},86400000*3),3);assert.equal(rules.dayAt(s,-100),3);assert.equal(rules.dayAt(s,1e20),70);
});
test('Deathtrain cycle boundaries use original durations',()=>{for(const [d,v]of [[0,3600],[24,86400],[25,3600],[26,7200],[49,90000],[50,1800],[60,19800]])assert.equal(rules.stormSeconds(d),v);});
test('failed craft leaves all materials untouched',()=>{r.setDay(40);p.inv.setItem(0,new I('minecraft:shulker_shell',1));r.craft(p,rules.recipeBook(40)[0]);assert.equal(p.inv.getItem(0).amount,1);});
test('valid craft consumes exact costs and returns output',()=>{p.inv.setItem(0,new I('minecraft:shulker_shell',3));p.inv.setItem(1,new I('minecraft:diamond_block',1));r.craft(p,rules.recipeBook(40)[0]);assert.equal(p.inv.getItem(0).amount,1);assert.equal(p.inv.getItem(1).typeId,'permadeath:end_relic');});
test('craft cannot bypass day gate',()=>{r.setDay(0);p.inv.setItem(0,new I('minecraft:shulker_shell',3));p.inv.setItem(1,new I('minecraft:diamond_block',1));r.craft(p,rules.recipeBook(0)[0]);assert.equal(p.inv.getItem(1).typeId,'minecraft:diamond_block');});
test('slot sealing relocates enchanted item data and unseals cleanly',()=>{
 r.setDay(40);const item=new I('minecraft:diamond_sword');item.nameTag='Conservar';item.setDynamicProperty('test',12);p.inv.setItem(4,item);r.enforceSlots(p,{});assert.equal(p.inv.getItem(4).typeId,'permadeath:locked_slot');assert.ok(Array.from({length:36},(_,i)=>p.inv.getItem(i)).some(x=>x?.nameTag==='Conservar'&&x.getDynamicProperty('test')===12));r.enforceSlots(p,{'permadeath:end_relic':1});assert.equal(p.inv.getItem(4),undefined);
});
test('life orb uses one heart of sea, eight stacks; all valid gates',()=>{const recipe=rules.recipeBook(60).find(x=>x.id.endsWith('life_orb'));assert.equal(recipe.cost['minecraft:heart_of_the_sea'],1);assert.equal(Object.values(recipe.cost).reduce((a,b)=>a+b),513);assert.equal(rules.recipeBook(60)[2].cost['minecraft:golden_apple'],64);});
test('phase HP, full armor and relic slots are distinct',()=>{assert.equal(rules.healthLimit(40,0,0,false,false),12);assert.equal(rules.healthLimit(60,2,10,false,true),6);assert.equal(rules.healthLimit(60,2,10,true,true),22);assert.equal(rules.lockedSlots(60,true,false).length,25);assert.equal(rules.lockedSlots(60,false,true).length,0);assert.equal(rules.lockedSlots(70,false,false).length,0);});
test('death saved once; reconnect remains spectator',()=>{r.setDay(10);const before=r.peek().state.storm;m.subscriptions['after:entityDie']({deadEntity:p});m.subscriptions['after:entityDie']({deadEntity:p});assert.equal(r.peek().state.storm,before+36000);assert.ok(JSON.parse(m.props.get('pd:state_v1')).dead.includes(p.name));m.subscriptions['after:playerSpawn']({player:p,initialSpawn:true});m.flush();assert.equal(p.mode,m.GameMode.Spectator);});
// Exercise actual asynchronous admin flow, including persistent resurrection.
p.addTag('pd_admin');m.answers.push({selection:2},{selection:0});await r.admin(p);
test('admin resurrection removes persistent death and survives reconnect',()=>{assert.ok(!r.peek().state.dead.includes(p.name));m.subscriptions['after:playerSpawn']({player:p,initialSpawn:true});m.flush();assert.equal(p.mode,m.GameMode.Survival);});
test('slot overflow spawn failure preserves original item',()=>{r.setDay(40);for(let i=0;i<36;i++)p.inv.setItem(i,new I('minecraft:stone',64));const original=p.dimension.spawnItem;p.dimension.spawnItem=()=>{throw Error('unloaded');};assert.throws(()=>r.enforceSlots(p,{}));assert.equal(p.inv.getItem(4).amount,64);p.dimension.spawnItem=original;});
test('native nonfatal hit cannot consume additional totems',()=>{for(let i=0;i<36;i++)p.inv.setItem(i);p.inv.setItem(0,new I('minecraft:totem_of_undying'));r.inspectTotem(p,1);assert.equal(p.inv.getItem(0).typeId,'minecraft:totem_of_undying');});
test('native consumed totem uses extras at day 60 without estimated armor damage',()=>{r.setDay(60);p.inv.setItem(0,new I('minecraft:totem_of_undying'));p.inv.setItem(1,new I('minecraft:totem_of_undying'));p.addEffect('regeneration',100,{});p.addEffect('fire_resistance',100,{});const rand=Math.random;Math.random=()=>.9;r.inspectTotem(p,3);Math.random=rand;assert.equal(p.inv.getItem(0),undefined);assert.equal(p.inv.getItem(1),undefined);});
test('all recipes have nonzero finite positive integer counts',()=>{for(const d of [0,25,40,60,70])for(const x of rules.recipeBook(d))for(const n of Object.values(x.cost))assert.ok(Number.isInteger(n)&&n>0);});
test('mob conversion spawn failure never deletes original',()=>{r.setDay(25);let removed=false;const e={id:'z',typeId:'minecraft:cow',isValid:true,nameTag:'',hasTag:()=>false,getComponent:k=>k==='minecraft:health'?{}:undefined,getDynamicProperty(){},location:p.location,dimension:{id:'minecraft:overworld',getEntities:()=>[],spawnEntity:()=>{throw Error('chunk unloaded');}},remove(){removed=true;}};assert.throws(()=>r.processMob(e));assert.equal(removed,false);});
console.log(`${passed} checks passed. Mock runtime only; not an in-game validation.`);
